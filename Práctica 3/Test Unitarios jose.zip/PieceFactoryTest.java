package model;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Sebastián Matheu Martínez
 */
public class PieceFactoryTest {

    @Test
    public void createPieceTest() 
    {
        assertTrue(PieceFactory.createPiece("I") instanceof IPiece);
        assertTrue(PieceFactory.createPiece("J") instanceof JPiece);
        assertTrue(PieceFactory.createPiece("L") instanceof LPiece);
        assertTrue(PieceFactory.createPiece("O") instanceof OPiece);
        assertTrue(PieceFactory.createPiece("S") instanceof SPiece);
        assertTrue(PieceFactory.createPiece("T") instanceof TPiece);
        assertTrue(PieceFactory.createPiece("Z") instanceof ZPiece);
        assertTrue(PieceFactory.createPiece("dasdasdas") == null);
    }
    
    @Test(expected = java.lang.NullPointerException.class)
    public void createPieceNullTest()
    {
        PieceFactory.createPiece(null);
    }
    
}
