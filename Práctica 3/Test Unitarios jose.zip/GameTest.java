package model;

import model.exceptions.CollisionMovementException;
import model.exceptions.CurrentPieceNotFixedException;
import model.exceptions.FixedPieceMovementException;
import model.exceptions.GameEndedMovementException;
import model.exceptions.NoCurrentPieceException;
import model.exceptions.OffBoardMovementException;
import model.exceptions.WrongSizeException;
import static org.junit.Assert.assertTrue;
import org.junit.Test;
import org.junit.Before;

/**
 *
 * @author Sebastián Matheu Martínez
 */
public class GameTest {
    
    private Game game, gameExc;
    
    @Before public void setUp() throws WrongSizeException
    {
        game = new Game(new Coordinate(5, 5));
    }
    
    @Test(expected = WrongSizeException.class)
    public void wrongSizePropagationConstructorTest() throws WrongSizeException
    {
        gameExc = new Game(new Coordinate(1, 1));
    }
    
    @Test(expected = java.lang.NullPointerException.class)
    public void nullConstructorTest() throws WrongSizeException
    {
        gameExc = new Game(null);
    }
    
    @Test(expected = NoCurrentPieceException.class)
    public void NoPieceLeftMovementExceptionTest() throws   NoCurrentPieceException, 
                                                            GameEndedMovementException, 
                                                            FixedPieceMovementException, 
                                                            OffBoardMovementException, 
                                                            CollisionMovementException 
    {
        game.moveCurrentPieceLeft();
    }
    
    @Test(expected = GameEndedMovementException.class)
    public void GameEndedLeftMovementExceptionTest() throws NoCurrentPieceException, 
                                                            GameEndedMovementException, 
                                                            FixedPieceMovementException, 
                                                            OffBoardMovementException, 
                                                            CollisionMovementException, 
                                                            CurrentPieceNotFixedException 
    {
        game.nextPiece("I");
        game.rotateCurrentPieceClockwise();
        game.moveCurrentPieceDown();
        game.moveCurrentPieceDown();
        game.nextPiece("I");
        
        game.moveCurrentPieceLeft();
    }
    
    @Test(expected = FixedPieceMovementException.class)
    public void FixedPieceLeftMovementExceptionTest() throws NoCurrentPieceException, 
                                                            GameEndedMovementException, 
                                                            FixedPieceMovementException, 
                                                            OffBoardMovementException, 
                                                            CollisionMovementException, 
                                                            CurrentPieceNotFixedException 
    {
        game.nextPiece("I");
        game.rotateCurrentPieceClockwise();
        game.moveCurrentPieceDown();
        game.moveCurrentPieceDown();
        
        game.moveCurrentPieceLeft();
    }
    
    @Test(expected = OffBoardMovementException.class)
    public void OffBoardLeftMovementExceptionTest() throws NoCurrentPieceException, 
                                                            GameEndedMovementException, 
                                                            FixedPieceMovementException, 
                                                            OffBoardMovementException, 
                                                            CollisionMovementException, 
                                                            CurrentPieceNotFixedException 
    {
        game.nextPiece("I");
        
        game.moveCurrentPieceLeft();
    }
    
    @Test(expected = CollisionMovementException.class)
    public void CollisionLeftMovementExceptionTest() throws NoCurrentPieceException, 
                                                            GameEndedMovementException, 
                                                            FixedPieceMovementException, 
                                                            OffBoardMovementException, 
                                                            CollisionMovementException, 
                                                            CurrentPieceNotFixedException 
    {
        game.nextPiece("I");
        game.rotateCurrentPieceClockwise();
        game.moveCurrentPieceLeft();
        game.moveCurrentPieceLeft();
        game.moveCurrentPieceDown();
        game.moveCurrentPieceDown();
        game.nextPiece("O");
        
        game.moveCurrentPieceLeft();
    }
    
    @Test(expected = NoCurrentPieceException.class)
    public void NoPieceRightMovementExceptionTest() throws   NoCurrentPieceException, 
                                                            GameEndedMovementException, 
                                                            FixedPieceMovementException, 
                                                            OffBoardMovementException, 
                                                            CollisionMovementException 
    {
        game.moveCurrentPieceRight();
    }
    
    @Test(expected = GameEndedMovementException.class)
    public void GameEndedRightMovementExceptionTest() throws NoCurrentPieceException, 
                                                            GameEndedMovementException, 
                                                            FixedPieceMovementException, 
                                                            OffBoardMovementException, 
                                                            CollisionMovementException, 
                                                            CurrentPieceNotFixedException 
    {
        game.nextPiece("I");
        game.rotateCurrentPieceClockwise();
        game.moveCurrentPieceDown();
        game.moveCurrentPieceDown();
        game.nextPiece("I");
        
        game.moveCurrentPieceRight();
    }
    
    @Test(expected = FixedPieceMovementException.class)
    public void FixedPieceRightMovementExceptionTest() throws NoCurrentPieceException, 
                                                            GameEndedMovementException, 
                                                            FixedPieceMovementException, 
                                                            OffBoardMovementException, 
                                                            CollisionMovementException, 
                                                            CurrentPieceNotFixedException 
    {
        game.nextPiece("I");
        game.rotateCurrentPieceClockwise();
        game.moveCurrentPieceDown();
        game.moveCurrentPieceDown();
        
        game.moveCurrentPieceRight();
    }
    
    @Test(expected = OffBoardMovementException.class)
    public void OffBoardRightMovementExceptionTest() throws NoCurrentPieceException, 
                                                            GameEndedMovementException, 
                                                            FixedPieceMovementException, 
                                                            OffBoardMovementException, 
                                                            CollisionMovementException, 
                                                            CurrentPieceNotFixedException 
    {
        game.nextPiece("I");
        
        game.moveCurrentPieceRight();
        game.moveCurrentPieceRight();
    }
    
    @Test(expected = CollisionMovementException.class)
    public void CollisionRightMovementExceptionTest() throws NoCurrentPieceException, 
                                                            GameEndedMovementException, 
                                                            FixedPieceMovementException, 
                                                            OffBoardMovementException, 
                                                            CollisionMovementException, 
                                                            CurrentPieceNotFixedException 
    {
        game.nextPiece("I");
        game.rotateCurrentPieceCounterclockwise();
        game.moveCurrentPieceRight();
        game.moveCurrentPieceRight();
        game.moveCurrentPieceDown();
        game.moveCurrentPieceDown();
        game.nextPiece("O");
        
        game.moveCurrentPieceRight();
    }
    
    @Test(expected = NoCurrentPieceException.class)
    public void noPieceDownMovementException() throws   NoCurrentPieceException, 
                                                        GameEndedMovementException, 
                                                        FixedPieceMovementException
    {
        game.moveCurrentPieceDown();
    }
    
    @Test(expected = GameEndedMovementException.class)
    public void gameEndedDownMovementException() throws NoCurrentPieceException, 
                                                        GameEndedMovementException, 
                                                        FixedPieceMovementException,
                                                        CurrentPieceNotFixedException,
                                                        OffBoardMovementException,
                                                        CollisionMovementException
    {
        game.nextPiece("I");
        game.rotateCurrentPieceClockwise();
        game.moveCurrentPieceDown();
        game.moveCurrentPieceDown();
        game.nextPiece("I");
        
        game.moveCurrentPieceDown();
    }
    
    @Test(expected = FixedPieceMovementException.class)
    public void fixedPieceDownMovementException() throws    NoCurrentPieceException, 
                                                            GameEndedMovementException, 
                                                            FixedPieceMovementException,
                                                            CurrentPieceNotFixedException,
                                                            OffBoardMovementException,
                                                            CollisionMovementException
    {
        game.nextPiece("I");
        game.rotateCurrentPieceClockwise();
        game.moveCurrentPieceDown();
        game.moveCurrentPieceDown();
        
        game.moveCurrentPieceDown();
    }
    
    @Test(expected = NoCurrentPieceException.class)
    public void noCurrentPieceCounterclockwiseExceptionTest() throws    NoCurrentPieceException, 
                                                                        GameEndedMovementException,
                                                                        FixedPieceMovementException,
                                                                        OffBoardMovementException,
                                                                        CollisionMovementException
    {
        game.rotateCurrentPieceCounterclockwise();
    }
    
    @Test(expected = GameEndedMovementException.class)
    public void gameEndedCounterclockwiseExceptionTest() throws NoCurrentPieceException, 
                                                                GameEndedMovementException, 
                                                                FixedPieceMovementException, 
                                                                OffBoardMovementException, 
                                                                CollisionMovementException, 
                                                                CurrentPieceNotFixedException
    {
        game.nextPiece("I");
        game.rotateCurrentPieceClockwise();
        game.moveCurrentPieceDown();
        game.moveCurrentPieceDown();
        game.nextPiece("I");
        
        game.rotateCurrentPieceCounterclockwise();
    }
    
    @Test(expected = FixedPieceMovementException.class)
    public void FixedPieceCounterclockwiseExceptionTest() throws    NoCurrentPieceException, 
                                                                GameEndedMovementException,
                                                                FixedPieceMovementException,
                                                                OffBoardMovementException,
                                                                CollisionMovementException,
                                                                CurrentPieceNotFixedException
    {
        game.nextPiece("I");
        game.rotateCurrentPieceClockwise();
        game.moveCurrentPieceDown();
        game.moveCurrentPieceDown();
        
        game.rotateCurrentPieceCounterclockwise();
    }
    
    @Test(expected = OffBoardMovementException.class)
    public void offBoardCounterclockwiseExceptionTest() throws  NoCurrentPieceException, 
                                                                GameEndedMovementException,
                                                                FixedPieceMovementException,
                                                                OffBoardMovementException,
                                                                CollisionMovementException,
                                                                CurrentPieceNotFixedException
    {
        game.nextPiece("I");
        game.rotateCurrentPieceCounterclockwise();
        game.moveCurrentPieceLeft();
        
        game.rotateCurrentPieceCounterclockwise();
    }
    
    @Test(expected = NoCurrentPieceException.class)
    public void noCurrentPieceClockwiseExceptionTest() throws   NoCurrentPieceException, 
                                                                GameEndedMovementException,
                                                                FixedPieceMovementException,
                                                                OffBoardMovementException,
                                                                CollisionMovementException
    {
        game.rotateCurrentPieceClockwise();
    }
    
    @Test(expected = GameEndedMovementException.class)
    public void gameEndedClockwiseExceptionTest() throws    NoCurrentPieceException, 
                                                            GameEndedMovementException, 
                                                            FixedPieceMovementException, 
                                                            OffBoardMovementException, 
                                                            CollisionMovementException, 
                                                            CurrentPieceNotFixedException
    {
        game.nextPiece("I");
        game.rotateCurrentPieceClockwise();
        game.moveCurrentPieceDown();
        game.moveCurrentPieceDown();
        game.nextPiece("I");
        
        game.rotateCurrentPieceClockwise();
    }
    
    @Test(expected = FixedPieceMovementException.class)
    public void FixedPieceClockwiseExceptionTest() throws   NoCurrentPieceException, 
                                                            GameEndedMovementException,
                                                            FixedPieceMovementException,
                                                            OffBoardMovementException,
                                                            CollisionMovementException,
                                                            CurrentPieceNotFixedException
    {
        game.nextPiece("I");
        game.rotateCurrentPieceClockwise();
        game.moveCurrentPieceDown();
        game.moveCurrentPieceDown();
        
        game.rotateCurrentPieceClockwise();
    }
    
    @Test(expected = OffBoardMovementException.class)
    public void offBoardClockwiseExceptionTest() throws NoCurrentPieceException, 
                                                        GameEndedMovementException,
                                                        FixedPieceMovementException,
                                                        OffBoardMovementException,
                                                        CollisionMovementException,
                                                        CurrentPieceNotFixedException
    {
        game.nextPiece("I");
        game.rotateCurrentPieceCounterclockwise();
        game.moveCurrentPieceLeft();
        
        game.rotateCurrentPieceClockwise();
    }
    
    @Test(expected = GameEndedMovementException.class)
    public void gameEndedNextPieceException() throws    GameEndedMovementException, 
                                                        CurrentPieceNotFixedException, 
                                                        NoCurrentPieceException, 
                                                        FixedPieceMovementException, 
                                                        OffBoardMovementException, 
                                                        CollisionMovementException
    {
        game.nextPiece("I");
        game.rotateCurrentPieceClockwise();
        game.moveCurrentPieceDown();
        game.moveCurrentPieceDown();
        game.nextPiece("I");
        game.nextPiece("I");
    }
    
    @Test(expected = CurrentPieceNotFixedException.class)
    public void currentPieceNotFixedNextPieceException() throws GameEndedMovementException, 
                                                                CurrentPieceNotFixedException
    {
        game.nextPiece("I");
        game.nextPiece("I");
    }
    
    @Test(expected = NoCurrentPieceException.class)
    public void isCurrentPieceFixedExceptionTest() throws NoCurrentPieceException
    {
        game.isCurrentPieceFixed();
    }
    
    @Test
    public void movePieceDownTest() throws  GameEndedMovementException, 
                                            CurrentPieceNotFixedException, 
                                            NoCurrentPieceException, 
                                            FixedPieceMovementException, 
                                            OffBoardMovementException, 
                                            CollisionMovementException
    {
        String expected =   "·····\n" +
                            "·····\n" +
                            "·····\n" +
                            "·····\n" +
                            "\u25a3\u25a3···\n";
        
        game.nextPiece("I");
        game.moveCurrentPieceDown();
        game.moveCurrentPieceDown();
        game.moveCurrentPieceDown();
        game.moveCurrentPieceDown();
        game.nextPiece("O");
        game.moveCurrentPieceLeft();
        game.moveCurrentPieceDown();
        game.moveCurrentPieceDown();
        game.moveCurrentPieceDown();
        game.nextPiece("J");
        game.moveCurrentPieceRight();
        game.rotateCurrentPieceClockwise();
        game.rotateCurrentPieceClockwise();
        game.moveCurrentPieceRight();
        game.moveCurrentPieceDown();
        game.moveCurrentPieceDown();
        game.moveCurrentPieceDown();
        
        assertTrue(expected.equals(game.toString()));
    }
}
