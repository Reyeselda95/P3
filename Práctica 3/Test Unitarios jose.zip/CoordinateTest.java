package model;

import org.junit.Test;
import org.junit.Before;

/**
 * 
 * @author Sebastián Matheu Martínez
 */
public class CoordinateTest {
    
    private Coordinate c, cNull;
    
    @Before public void setUp()
    {
        c = new Coordinate(1, 1);
    }
    
    @Test(expected = java.lang.NullPointerException.class)
    public void contructorNullTest()
    {
        cNull = new Coordinate(null);
    }
    
    @Test(expected = java.lang.NullPointerException.class)
    public void addNullTest()
    {
        c.add(null);
    }
}
