package model;

import model.exceptions.WrongSizeException;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.Before;

/**
 * 
 * @author Sebastián Matheu Martínez
 */
public class GameboardTest {
    
    private Gameboard board, boardExc;
    
    @Before public void setUp() throws WrongSizeException
    {
        board = new Gameboard(new Coordinate(5, 5));
    }
    
    @Test(expected = WrongSizeException.class) 
    public void wrongSizeConstructorTest() throws WrongSizeException
    {
        boardExc = new Gameboard(new Coordinate(1, 1));
    }
    
    @Test(expected = java.lang.NullPointerException.class)
    public void nullConstructor() throws WrongSizeException
    {
        boardExc = new Gameboard(null);
    }
    
    @Test(expected = java.lang.NullPointerException.class)
    public void putNullsTest()
    {
        board.putPiece(null, null);
    }
    
    @Test(expected = java.lang.NullPointerException.class)
    public void placeValidNullTest()
    {
        board.isPlaceValid(null, null);
    }
    
    @Test(expected = java.lang.NullPointerException.class)
    public void placeFreeNullTest()
    {
        board.isPlaceFree(null, null);
    }
    
    @Test(expected = java.lang.NullPointerException.class)
    public void removeNullTest()
    {
        board.removePiece(null);
    }
    
    @Test(expected = java.lang.NullPointerException.class)
    public void getNullsTest()
    {
        board.getCellContent(null);
    }
    
    @Test(expected = java.lang.NullPointerException.class)
    public void setNullsTest()
    {
        board.setCellContent(null, null);
    }
    
    @Test(expected = java.lang.IllegalArgumentException.class)
    public void isRowNotIntTest() throws java.lang.IllegalArgumentException
    {
        //board.isRowFull(-1);
    }
    
    @Test
    public void firstRowFullFromBottomTest()
    {
        assertTrue(board.firstRowFullFromBottom() == -1);
        
        board.setCellContent(new Coordinate(3, 0), new IPiece());
        board.setCellContent(new Coordinate(3, 1), new IPiece());
        board.setCellContent(new Coordinate(3, 2), new IPiece());
        board.setCellContent(new Coordinate(3, 3), new IPiece());
        board.setCellContent(new Coordinate(3, 4), new IPiece());
        
        //Estas piezas no estan fijas, si te falla aqui es porque no estas revisando que las posiciones ocupadas
        //esten rellenas por piezas fijadas
        assertFalse(board.firstRowFullFromBottom() == 3);
        
        IPiece p = new IPiece();
        p.setFixed(true);
        board.setCellContent(new Coordinate(2, 0), p);
        board.setCellContent(new Coordinate(2, 1), p);
        board.setCellContent(new Coordinate(2, 2), p);
        board.setCellContent(new Coordinate(2, 3), p);
        board.setCellContent(new Coordinate(2, 4), p);
        
        
        assertTrue(board.firstRowFullFromBottom() == 2);
    }
    
    @Test(expected = java.lang.IllegalArgumentException.class)
    public void clearRowExceptionTest()
    {
        board.clearRow(-1);
    }
    
    @Test(expected = java.lang.IllegalArgumentException.class)
    public void makeUpperRowsFallExceptionTest()
    {
        board.makeUpperRowsFall(-1);
    }
        
    @Test
    public void makeUpperRowsFallTest()
    {        
        IPiece p = new IPiece();
        p.setFixed(true);
        
        String expected =   "·····\n" +
                            "·····\n" +
                            "·····\n" +
                            "·····\n" +
                            p.getBlockSymbol() +
                            p.getBlockSymbol() +
                            p.getBlockSymbol() +
                            p.getBlockSymbol() +
                            p.getBlockSymbol() + "\n";
        
        board.setCellContent(new Coordinate(3, 0), p);
        board.setCellContent(new Coordinate(3, 1), p);
        board.setCellContent(new Coordinate(3, 2), p);
        board.setCellContent(new Coordinate(3, 3), p);
        board.setCellContent(new Coordinate(3, 4), p);
        
        board.makeUpperRowsFall(4);
        
        assertTrue(expected.equals(board.toString()));
    }
}
